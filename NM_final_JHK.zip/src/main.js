import './styles/style.css'
import * as THREE from 'three'
import Lenis from '@studio-freight/lenis'
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';



console.log('hello')

//Lenis
const lenis = new Lenis()

lenis.on('scroll', (e) => {
  console.log(lenis.velocity)
})

function raf(time) {
  lenis.raf(time)
  requestAnimationFrame(raf)
}

requestAnimationFrame(raf)

const scene = new THREE.Scene()


const sizes = {
    width: window.innerWidth,
    height : window.innerHeight
}

window.addEventListener('resize', ()=>{
    sizes.width = window.innerWidth
    sizes.height = window.innerHeight

    camera.aspect = sizes.width / sizes.height
    camera.updateProjectionMatrix()

    renderer.setSize(sizes.width, sizes.height)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
})

//Camera

const camera = new THREE.PerspectiveCamera(75, sizes.width /sizes.height, 0.1, 100)

camera.position.z = 10
scene.add(camera)

//Light

const mainLight = new THREE.PointLight('white', 10)
mainLight.position.set(1, 1, 0)

const secondLight = new THREE.PointLight('white', 10)
secondLight.position.set(-1, -1, 0)

const ambientLight = new THREE.AmbientLight('white', 1)

scene.add(mainLight, secondLight, ambientLight)


const geometry = new THREE.BoxGeometry(1, 1, 1)
const material = new THREE.MeshNormalMaterial()
const mesh = new THREE.Mesh(geometry, material)
scene.add(mesh)


mesh.rotation.x += lenis.progress * 10
mesh.rotation.y += lenis.progress * 20

lenis.on('scroll', () => {
    mesh.rotation.x = lenis.progress * 10
    mesh.rotation.y = lenis.progress * 20
  })


  
const loader = new GLTFLoader()

loader.load('https://uploads-ssl.webflow.com/65769a5c761f169cdbc70e60/6578de28212436d1f48055ff_manggom2.glb.txt',
    ( gltf ) => {
        let model = gltf.scene
		scene.add( model );
    
        lenis.on('scroll', () => {
            model.rotation.x = lenis.progress * 10
            model.rotation.y = lenis.progress * 20
           
          })

	}
	
);

const canvas = document.querySelector('canvas.webgl')
const renderer = new THREE.WebGLRenderer({
    canvas : canvas,
    antialias: true,
    alpha : true
})


renderer.setSize(sizes.width, sizes.height)
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))


function animate(){

    renderer.render(scene, camera)
    requestAnimationFrame(animate)
}

animate()

